import PogObject from "../PogData/index"

export const data = new PogObject("PredevTimer", {
    predevTimer: {
        pb: 999999999
    },
}, "data.json")